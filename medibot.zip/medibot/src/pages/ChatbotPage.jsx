import React, { useEffect, useState } from "react";
import { askMedicalBot } from "../lib/api.js";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faRobot,
  faUser,
  faPaperPlane,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";

export default function ChatbotPage({ userType, doctorId }) {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const [showPatientModal, setShowPatientModal] = useState(true);
  const [patientIC, setPatientIC] = useState("");
  const [patientName, setPatientName] = useState("");

  useEffect(() => {
    setShowPatientModal(true);
  }, []);

  function openPatientModal() {
    setShowPatientModal(true);
  }

  function handlePatientICSubmit() {
    if (!patientIC.trim()) return;
    setPatientName(userType === "medical" ? "Santoosh" : "You");
    setShowPatientModal(false);
  }

  async function handleSend() {
    const text = inputText.trim();
    if (!text) return;

    if (!patientIC.trim()) {
      openPatientModal();
      return;
    }

    setMessages((m) => [...m, { text, sender: "user" }]);
    setInputText("");
    setIsTyping(true);

    try {
      const answer = await askMedicalBot({
        patientId: patientIC,
        query: text,
        doctorId: doctorId || "123456789",
      });

      const reply =
        answer && answer.trim() ? answer.trim() : "No answer returned.";
      setMessages((m) => [...m, { text: reply, sender: "bot" }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        {
          text:
            "Sorry, I couldn't reach the medical service.\n\n" +
            (err?.message || "Unknown error"),
          sender: "bot",
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  }

  return (
    <div className="page">
      <h2>What can I do for you today?</h2>

      {patientName && (
        <div className="patient-name">
          Patient: {patientName} ({patientIC})
          <button
            className="btn btn-primary"
            style={{ marginLeft: 12, padding: "6px 10px" }}
            onClick={openPatientModal}
          >
            Change Patient
          </button>
        </div>
      )}

      <div className="card">
        <div className="chat-container">
          <div className="chat-messages">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`message ${
                  msg.sender === "user" ? "user-message" : "bot-message"
                }`}
              >
                <div
                  className={`avatar ${
                    msg.sender === "user" ? "user-avatar" : "eva-avatar"
                  }`}
                >
                  <FontAwesomeIcon
                    icon={msg.sender === "user" ? faUser : faRobot}
                  />
                </div>
                <div style={{ whiteSpace: "pre-wrap" }}>{msg.text}</div>
              </div>
            ))}

            {isTyping && (
              <div className="message bot-message">
                <div className="avatar eva-avatar">
                  <FontAwesomeIcon icon={faRobot} />
                </div>
                <div>
                  <span className="typing-animation">Typing</span>
                </div>
              </div>
            )}
          </div>

          <div className="chat-input">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Type your medical query..."
            />
            <button onClick={handleSend} aria-label="Send">
              <FontAwesomeIcon icon={faPaperPlane} />
            </button>
          </div>
        </div>
      </div>

      {showPatientModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Enter Patient IC Number</h3>
              <button
                className="modal-close"
                onClick={() => setShowPatientModal(false)}
                aria-label="Close"
              >
                <FontAwesomeIcon icon={faTimes} />
              </button>
            </div>

            <div className="form-group">
              <label>Patient IC</label>
              <input
                value={patientIC}
                onChange={(e) => setPatientIC(e.target.value)}
                placeholder="e.g., P12345"
              />
            </div>

            <div className="form-group">
              <label>Doctor ID (used for requests)</label>
              <input value={doctorId || "D67890"} disabled />
              <p
                style={{ color: "var(--text-dim)", fontSize: 12, marginTop: 6 }}
              >
                Change Doctor ID in <strong>Settings</strong>.
              </p>
            </div>

            <button
              className="btn btn-primary"
              onClick={handlePatientICSubmit}
              style={{ width: "100%" }}
            >
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
