import React, { useState } from "react";

export default function SettingsPage({
  isLightMode,
  setIsLightMode,
  doctorId,
  setDoctorId,
}) {
  const [settings, setSettings] = useState({
    twoFactor: false,
    dataRetention: "1year",
    sessionTimeout: 30,
    notifications: true,
  });

  const set = (k, v) => setSettings((s) => ({ ...s, [k]: v }));

  return (
    <div className="page">
      <h2>Settings</h2>
      <p>Customize your experience and manage preferences</p>

      <div className="settings-section">
        <h3 className="card-title">Account & Profile</h3>
        <div className="settings-item">
          <div>
            <h4>Two-Factor Authentication</h4>
            <p>Add an extra layer of security to your account</p>
          </div>
          <label className="toggle-switch">
            <input
              type="checkbox"
              checked={settings.twoFactor}
              onChange={(e) => set("twoFactor", e.target.checked)}
            />
            <span className="slider" />
          </label>
        </div>
      </div>

      <div className="settings-section">
        <h3 className="card-title">Data Access & Privacy</h3>
        <div className="settings-item">
          <div>
            <h4>Data Retention</h4>
            <p>How long we keep your data</p>
          </div>
          <select
            value={settings.dataRetention}
            onChange={(e) => set("dataRetention", e.target.value)}
            style={{
              padding: 8,
              borderRadius: 5,
              background: "var(--card-bg)",
              color: "var(--text-light)",
              border: "1px solid var(--primary-purple)",
            }}
          >
            <option value="30days">30 Days</option>
            <option value="6months">6 Months</option>
            <option value="1year">1 Year</option>
            <option value="indefinite">Indefinitely</option>
          </select>
        </div>
      </div>

      <div className="settings-section">
        <h3 className="card-title">Security & Compliance</h3>
        <div className="settings-item">
          <div>
            <h4>Session Timeout</h4>
            <p>Automatically log out after inactivity</p>
          </div>
          <select
            value={settings.sessionTimeout}
            onChange={(e) => set("sessionTimeout", e.target.value)}
            style={{
              padding: 8,
              borderRadius: 5,
              background: "var(--card-bg)",
              color: "var(--text-light)",
              border: "1px solid var(--primary-purple)",
            }}
          >
            <option value="15">15 Minutes</option>
            <option value="30">30 Minutes</option>
            <option value="60">1 Hour</option>
            <option value="120">2 Hours</option>
          </select>
        </div>
      </div>

      <div className="settings-section">
        <h3 className="card-title">Interface & API</h3>

        <div className="settings-item">
          <div>
            <h4>Dark Mode</h4>
            <p>Switch between dark and light themes</p>
          </div>
          <label className="toggle-switch">
            <input
              type="checkbox"
              checked={isLightMode}
              onChange={(e) => setIsLightMode(e.target.checked)}
            />
            <span className="slider" />
          </label>
        </div>

        <div className="settings-item">
          <div>
            <h4>Doctor ID</h4>
            <p>ID to include with chat requests to the medical API</p>
          </div>
          <input
            value={doctorId}
            onChange={(e) => setDoctorId(e.target.value)}
            style={{
              padding: 10,
              borderRadius: 8,
              border: "1px solid var(--primary-purple)",
              background: "var(--card-bg)",
              color: "var(--text)",
              width: 180,
            }}
          />
        </div>
      </div>

      <div className="settings-section">
        <h3 className="card-title">Support & Feedback</h3>
        <div className="settings-item">
          <div>
            <h4>Contact Support</h4>
            <p>Get help with any issues or questions</p>
          </div>
          <button className="btn btn-primary">Contact</button>
        </div>

        <div className="settings-item">
          <div>
            <h4>Submit Feedback</h4>
            <p>Share your thoughts and suggestions</p>
          </div>
          <button className="btn btn-primary">Submit</button>
        </div>
      </div>
    </div>
  );
}
