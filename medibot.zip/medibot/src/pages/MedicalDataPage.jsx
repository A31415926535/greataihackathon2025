import React from "react";

export default function MedicalDataPage() {
  const medicalSummary = {
    bloodType: "A+",
    allergies: "Penicillin, Pollen",
    recentVisits: "Annual Checkup (June 2023), Dermatology (May 2023)",
    recentSurgeries: "Appendectomy (2018)",
    medications: "Lisinopril 10mg daily, Metformin 500mg twice daily",
  };

  return (
    <div className="page">
      <div className="centered-content">
        <h2>My Medical Data</h2>
        <p>View your medical information and history</p>
      </div>

      <div className="card">
        <h3 className="card-title">Medical Summary</h3>
        <div className="medical-summary">
          <div className="summary-item">
            <h4>Blood Type</h4>
            <p>{medicalSummary.bloodType}</p>
          </div>
          <div className="summary-item">
            <h4>Allergies</h4>
            <p>{medicalSummary.allergies}</p>
          </div>
          <div className="summary-item">
            <h4>Recent Visits</h4>
            <p>{medicalSummary.recentVisits}</p>
          </div>
          <div className="summary-item">
            <h4>Recent Surgeries</h4>
            <p>{medicalSummary.recentSurgeries}</p>
          </div>
          <div className="summary-item">
            <h4>Medications</h4>
            <p>{medicalSummary.medications}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
