import React, { useEffect, useState } from "react";
import Header from "./components/Header.jsx";
import Sidebar from "./components/Sidebar.jsx";

import RoleSelectionPage from "./pages/RoleSelectionPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import VerificationPage from "./pages/VerificationPage.jsx";
import ChatbotPage from "./pages/ChatbotPage.jsx";
import DocumentsPage from "./pages/DocumentsPage.jsx";
import ReportsPage from "./pages/ReportsPage.jsx";
import MedicalDataPage from "./pages/MedicalDataPage.jsx";
import SummaryPage from "./pages/SummaryPage.jsx";
import SettingsPage from "./pages/SettingsPage.jsx";

export default function App() {
  const [userType, setUserType] = useState(null); // "medical" | "patient"
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [verificationStage, setVerificationStage] = useState(false);
  const [currentPage, setCurrentPage] = useState("chatbot");
  const [email, setEmail] = useState("");
  const [isLightMode, setIsLightMode] = useState(false);

  // app-level doctorId (editable in settings, persists in localStorage)
  const [doctorId, setDoctorId] = useState(
    () => localStorage.getItem("doctorId") || "D67890"
  );

  // toggle dark/light theme
  useEffect(() => {
    document.body.classList.toggle("light-mode", isLightMode);
  }, [isLightMode]);

  // persist doctorId
  useEffect(() => {
    localStorage.setItem("doctorId", doctorId);
  }, [doctorId]);

  const handleUserTypeSelect = (type) => {
    setUserType(type); // "medical" | "patient"
  };

  const handleLogin = (userEmail) => {
    setEmail(userEmail);
    setVerificationStage(true);
  };

  const handleVerificationComplete = () => {
    setIsLoggedIn(true);
    setVerificationStage(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setEmail("");
    setUserType(null);
    setVerificationStage(false);
    setCurrentPage("chatbot");
    setDoctorId("D67890"); // reset doctor ID on logout
  };

  // Step 1: role selection
  if (!userType) {
    return (
      <RoleSelectionPage
        onSelect={handleUserTypeSelect}
        isLightMode={isLightMode}
        setIsLightMode={setIsLightMode}
      />
    );
  }

  // Step 2: login
  if (!isLoggedIn && !verificationStage) {
    return (
      <LoginPage
        onLogin={handleLogin}
        userType={userType}
        isLightMode={isLightMode}
        setIsLightMode={setIsLightMode}
      />
    );
  }

  // Step 3: verification
  if (verificationStage) {
    return (
      <VerificationPage
        email={email}
        onVerificationComplete={handleVerificationComplete}
      />
    );
  }

  // Step 4: main app
  return (
    <div className="app">
      <Header email={email} onLogout={handleLogout} userType={userType} />

      <div className="main-content">
        <Sidebar
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          userType={userType}
        />

        <div className="page-content">
          {currentPage === "chatbot" && (
            <ChatbotPage userType={userType} doctorId={doctorId} />
          )}

          {currentPage === "documents" && <DocumentsPage userType={userType} />}

          {currentPage === "reports" && userType === "patient" && (
            <ReportsPage />
          )}

          {currentPage === "medicaldata" && userType === "patient" && (
            <MedicalDataPage />
          )}

          {currentPage === "summary" && userType === "medical" && (
            <SummaryPage />
          )}

          {currentPage === "settings" && (
            <SettingsPage
              isLightMode={isLightMode}
              setIsLightMode={setIsLightMode}
              userType={userType}
              doctorId={doctorId}
              setDoctorId={setDoctorId}
            />
          )}
        </div>
      </div>
    </div>
  );
}
