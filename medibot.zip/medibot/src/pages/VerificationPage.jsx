import React, { useState } from "react";

export default function VerificationPage({ onVerificationComplete, email }) {
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");

  const onChange = (i, v) => {
    if (!/^\d*$/.test(v)) return;
    const next = [...code];
    next[i] = v;
    setCode(next);
    if (v && i < 5) document.getElementById(`verification-${i + 1}`).focus();
    setError("");
  };

  const onKeyDown = (i, e) => {
    if (e.key === "Backspace" && !code[i] && i > 0) {
      document.getElementById(`verification-${i - 1}`).focus();
    }
  };

  const submit = () => {
    if (code.join("").length !== 6)
      return setError("Please enter the full 6-digit code");
    onVerificationComplete(); // accept any 6 digits
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <h2 className="form-title">Email Verification</h2>
        <p style={{ textAlign: "center", marginBottom: "1.5rem" }}>
          Enter the 6-digit code sent to {email}
        </p>

        <div className="verification-inputs">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <input
              key={i}
              id={`verification-${i}`}
              className="verification-input"
              maxLength="1"
              value={code[i]}
              onChange={(e) => onChange(i, e.target.value)}
              onKeyDown={(e) => onKeyDown(i, e)}
            />
          ))}
        </div>

        {error && (
          <p
            style={{ color: "red", textAlign: "center", marginBottom: "1rem" }}
          >
            {error}
          </p>
        )}

        <button
          className="btn btn-primary"
          onClick={submit}
          style={{ width: "100%" }}
        >
          Verify Code
        </button>

        <div className="form-footer">
          <p>
            Didn't receive the code?
            <a href="#" style={{ color: "var(--accent)", marginLeft: 5 }}>
              Resend
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
