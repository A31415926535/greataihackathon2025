import React, { useState } from "react";

export default function LoginPage({
  onLogin,
  userType,
  isLightMode,
  setIsLightMode,
}) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [medicalId, setMedicalId] = useState("");
  const [icNumber, setIcNumber] = useState("");

  const submit = (e) => {
    e.preventDefault();
    // no real auth — just forward email to trigger verification stage
    onLogin(email);
  };

  return (
    <div className="login-container">
      <div className="theme-toggle">
        <label className="toggle-switch">
          <input
            type="checkbox"
            checked={isLightMode}
            onChange={(e) => setIsLightMode(e.target.checked)}
          />
          <span className="slider" />
        </label>
      </div>

      <div className="login-form">
        <h2 className="form-title">
          {userType === "medical" ? "Medical Staff " : "Patient "}
          {isLogin ? "Login" : "Create Account"}
        </h2>

        <form onSubmit={submit}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
            />
          </div>

          {userType === "medical" && (
            <div className="form-group">
              <label>Medical ID</label>
              <input
                value={medicalId}
                onChange={(e) => setMedicalId(e.target.value)}
                placeholder="Enter your medical ID"
              />
            </div>
          )}

          {userType === "patient" && (
            <div className="form-group">
              <label>IC Number</label>
              <input
                value={icNumber}
                onChange={(e) => setIcNumber(e.target.value)}
                placeholder="Enter your IC number"
              />
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: "100%", padding: 15 }}
          >
            {isLogin ? "Login" : "Create Account"}
          </button>
        </form>

        <div className="form-footer">
          <p>
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <a
              href="#"
              onClick={() => setIsLogin(!isLogin)}
              style={{ color: "var(--accent)" }}
            >
              {isLogin ? "Sign up" : "Login"}
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
