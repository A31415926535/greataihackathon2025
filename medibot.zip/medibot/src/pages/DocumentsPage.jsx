import React, { useState } from "react";

export default function DocumentsPage() {
  const [uploadType, setUploadType] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [patientIC, setPatientIC] = useState("");
  const [patientName, setPatientName] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [showFileBrowser, setShowFileBrowser] = useState(false);

  const handleUpload = () => {
    // placeholder: later wire to your API
    setShowUploadModal(false);
    setShowFileBrowser(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 1500);
  };

  if (showSuccess) {
    return (
      <div className="page">
        <div className="success-animation">
          <i className="fas fa-check-circle" style={{ color: "green" }} />
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="centered-content">
        <h2>Medical Document Repository</h2>
        <p>Upload and manage medical documents</p>
      </div>

      <div className="card">
        <h3 className="card-title">Upload Documents</h3>
        <div className="upload-area" onClick={() => setShowUploadModal(true)}>
          <i className="fas fa-cloud-upload-alt" />
          <p>Click to upload documents</p>
        </div>
      </div>

      {showUploadModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Select Upload Type</h3>
              <button
                className="modal-close"
                onClick={() => setShowUploadModal(false)}
              >
                <i className="fas fa-times" />
              </button>
            </div>

            {!uploadType ? (
              <div
                style={{
                  display: "flex",
                  gap: "1rem",
                  justifyContent: "center",
                }}
              >
                <button
                  className="btn btn-primary"
                  onClick={() => setUploadType("guidelines")}
                >
                  Clinical Guidelines
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => setUploadType("patient")}
                >
                  Patient Documents
                </button>
              </div>
            ) : uploadType === "patient" ? (
              <>
                {!showFileBrowser ? (
                  <>
                    <div className="form-group">
                      <label>Patient IC</label>
                      <input
                        value={patientIC}
                        onChange={(e) => setPatientIC(e.target.value)}
                        placeholder="Enter patient IC number"
                      />
                    </div>
                    <button
                      className="btn btn-primary"
                      onClick={() => {
                        if (patientIC) {
                          setPatientName("John Doe");
                          setShowFileBrowser(true);
                        }
                      }}
                      style={{ width: "100%", marginBottom: "1rem" }}
                    >
                      Verify IC
                    </button>
                  </>
                ) : (
                  <>
                    <div
                      className="patient-name"
                      style={{ marginBottom: "1rem" }}
                    >
                      Patient: {patientName}
                    </div>
                    <div className="upload-area" onClick={handleUpload}>
                      <i className="fas fa-file-medical" />
                      <p>Click to upload patient documents</p>
                    </div>
                  </>
                )}
                <button
                  className="btn"
                  onClick={() => {
                    setUploadType(null);
                    setShowFileBrowser(false);
                  }}
                >
                  Back
                </button>
              </>
            ) : (
              <>
                <div className="upload-area" onClick={handleUpload}>
                  <i className="fas fa-file-medical" />
                  <p>Upload Clinical Guidelines</p>
                </div>
                <button
                  className="btn"
                  onClick={() => setUploadType(null)}
                  style={{ width: "100%", marginTop: ".5rem" }}
                >
                  Back
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
