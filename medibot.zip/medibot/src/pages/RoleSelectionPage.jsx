import React from "react";

export default function RoleSelectionPage({
  onSelect,
  isLightMode,
  setIsLightMode,
}) {
  return (
    <div className="role-selection">
      <div className="theme-toggle">
        <label className="toggle-switch">
          <input
            type="checkbox"
            checked={isLightMode}
            onChange={(e) => setIsLightMode(e.target.checked)}
          />
          <span className="slider" />
        </label>
      </div>

      <div className="role-container">
        <div className="role-card" onClick={() => onSelect("medical")}>
          <i className="fas fa-user-md" />
          <h2>Medical Staff</h2>
          <p>Access patient records, analyze data, and upload documents</p>
        </div>
        <div className="role-card" onClick={() => onSelect("patient")}>
          <i className="fas fa-user" />
          <h2>Patient</h2>
          <p>
            View your medical records, lab results, and chat about your health
          </p>
        </div>
      </div>
    </div>
  );
}
