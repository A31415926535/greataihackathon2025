// src/pages/SummaryPage.jsx
import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCalendar, faFilePdf } from "@fortawesome/free-solid-svg-icons";

export default function SummaryPage() {
  const patient = {
    name: "Santoosh",
    ic: "621001-01-2468",
    sex: "Male",
    blood_type: "B+",
  };

  const diseaseHistory = [
    {
      date: "2024-01-23",
      disease: "Diabetes Mellitus Type 2",
      type: "c",
      reference: "1872483-MED-20240123",
    },
    {
      date: "2024-08-29",
      disease: "Diabetes Mellitus with Diabetic Ketoacidosis (DKA)",
      type: "i",
      reference: "1872483-MED-20240829",
    },
    {
      date: "2025-01-07",
      disease: "Diabetes Mellitus Type 1 (Post-DKA, Stabilized)",
      type: "c",
      reference: "1872483-MED-20250107",
    },
  ];

  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="page">
      {/* Patient Summary Header */}
      <div className="patient-summary-header">
        <div className="patient-summary-title">
          <h2>Patient Summary</h2>
          <p>
            Comprehensive overview of patient information and medical history
          </p>
        </div>
        <div className="patient-summary-action">
          <button className="btn btn-primary">Change Patient</button>
        </div>
      </div>

      {/* Patient Info Grid */}
      <div className="patient-info-grid">
        <div className="info-card">
          <h4>Patient Name</h4>
          <p>{patient.name}</p>
        </div>
        <div className="info-card">
          <h4>IC Number</h4>
          <p>{patient.ic}</p>
        </div>
        <div className="info-card">
          <h4>Sex</h4>
          <p>{patient.sex}</p>
        </div>
        <div className="info-card">
          <h4>Blood Type</h4>
          <p>{patient.blood_type}</p>
        </div>
      </div>

      {/* Medical History Timeline */}
      <div className="card">
        <h3 className="card-title">Medical History</h3>

        <div className="disease-timeline">
          {diseaseHistory.map((d, index) => (
            <div key={index} className="timeline-item">
              {/* Left side icon */}
              <div className="timeline-icon">
                <FontAwesomeIcon icon={faCalendar} />
              </div>

              {/* Right side content */}
              <div className="timeline-content">
                <span
                  className={`disease-type ${
                    d.type === "c" ? "type-chronic" : "type-infectious"
                  }`}
                >
                  {d.type === "c" ? "Chronic" : "Infectious"}
                </span>

                <h4 style={{ fontWeight: "bold", margin: "0.5rem 0" }}>
                  {d.disease}
                </h4>

                <p style={{ marginBottom: "0.8rem" }}>
                  Diagnosed on: {formatDate(d.date)}
                </p>

                <a
                  href={`${d.reference}.pdf`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="reference-link"
                >
                  <FontAwesomeIcon icon={faFilePdf} /> View Medical Report
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
