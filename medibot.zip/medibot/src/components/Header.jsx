// src/components/Header.jsx
import React from "react";

function Header({ email, onLogout, userType }) {
  return (
    <header>
      <div className="logo">
        <i className="fas fa-brain" aria-hidden="true" />
        <span>MediBot</span>
      </div>

      <div>
        {email && (
          <span style={{ marginRight: 15 }}>
            {email} ({userType === "medical" ? "Medical Staff" : "Patient"})
          </span>
        )}
        <button type="button" className="btn btn-primary" onClick={onLogout}>
          <i className="fas fa-sign-out-alt" aria-hidden="true" /> Sign Out
        </button>
      </div>
    </header>
  );
}

export default Header;
