import React from "react";

export default function Sidebar({ currentPage, setCurrentPage, userType }) {
  const Item = ({ id, icon, label, show = true }) =>
    show ? (
      <a
        className={`nav-item ${currentPage === id ? "active" : ""}`}
        onClick={() => setCurrentPage(id)}
      >
        <i className={`fas ${icon}`} />
        <span>{label}</span>
      </a>
    ) : null;

  return (
    <div className="sidebar">
      <Item id="chatbot" icon="fa-robot" label="Medical Chatbot" />
      <Item
        id="summary"
        icon="fa-notes-medical"
        label="Patient Summary"
        show={userType === "medical"}
      />
      <Item
        id="documents"
        icon="fa-file-upload"
        label="Upload Documents"
        show={userType === "medical"}
      />
      <Item
        id="medicaldata"
        icon="fa-file-medical"
        label="Medical Data"
        show={userType === "patient"}
      />
      <Item
        id="reports"
        icon="fa-chart-line"
        label="Lab Reports"
        show={userType === "patient"}
      />
      <Item id="settings" icon="fa-cog" label="Settings" />
    </div>
  );
}
