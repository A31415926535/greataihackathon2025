import React, { useState } from "react";

export default function ReportsPage() {
  const [expanded, setExpanded] = useState(null);
  const labData = [
    {
      title: "Blood Glucose Level",
      patientValue: 125,
      normalValue: 100,
      unit: "mg/dL",
      status: "High",
      recommendations:
        "Your blood sugar levels have been slightly elevated over the past month. Consider reducing sugar intake and increasing physical activity.",
    },
    {
      title: "Blood Pressure",
      patientValue: 135,
      normalValue: 120,
      unit: "mmHg",
      status: "Elevated",
      recommendations:
        "Your blood pressure is slightly elevated. Consider reducing sodium intake, exercising regularly, and managing stress.",
    },
    {
      title: "Cholesterol Level",
      patientValue: 180,
      normalValue: 200,
      unit: "mg/dL",
      status: "Normal",
      recommendations:
        "Your cholesterol levels are within normal range. Maintain your current diet and exercise routine.",
    },
  ];

  return (
    <div className="page">
      <div className="centered-content">
        <h2>Lab Report Summary</h2>
        <p>Comprehensive overview of your lab results and trends</p>
      </div>

      <div className="card">
        <h3 className="card-title">Latest Results</h3>
        <div className="summary-cards">
          {labData.map((d, i) => (
            <div key={i} className="summary-card">
              <i className="fas fa-vial" />
              <h3>{d.title}</h3>
              <h2>
                {d.patientValue} {d.unit}
              </h2>
              <p
                style={{ color: d.status === "Normal" ? "#4dff4d" : "#ff4d4d" }}
              >
                {d.status}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3 className="card-title">Trend Analysis</h3>
        <div className="graph-container">
          {labData.map((d, i) => (
            <div
              key={i}
              className={`graph ${expanded === i ? "expanded" : ""}`}
              onClick={() => setExpanded(expanded === i ? null : i)}
            >
              <div className="graph-header">
                <h4>{d.title}</h4>
                <i
                  className={`fas ${
                    expanded === i ? "fa-compress" : "fa-expand"
                  }`}
                />
              </div>

              <div className="graph-bars">
                <div className="graph-bar-container">
                  <div className="graph-bar-label">Normal Level:</div>
                  <div
                    className="graph-bar graph-bar-normal"
                    style={{ width: `${(d.normalValue / 250) * 100}%` }}
                  >
                    <span className="graph-bar-value">
                      {d.normalValue} {d.unit}
                    </span>
                  </div>
                </div>
                <div className="graph-bar-container">
                  <div className="graph-bar-label">Your Level:</div>
                  <div
                    className="graph-bar graph-bar-patient"
                    style={{ width: `${(d.patientValue / 250) * 100}%` }}
                  >
                    <span className="graph-bar-value">
                      {d.patientValue} {d.unit}
                    </span>
                  </div>
                </div>
              </div>

              <div className="graph-content">
                <p>{d.recommendations}</p>
                <p>
                  <strong>Recommendations:</strong> Monitor regularly, maintain
                  a balanced diet, and follow your doctor's advice.
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
